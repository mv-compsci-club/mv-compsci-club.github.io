import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;


public class EdgeDetectionHelper {
	private int threshold;
	private BufferedImage img;
	
	public EdgeDetectionHelper(int thresholdVal, String imageName) {
		threshold = thresholdVal;
		
		try {
			img = ImageIO.read(new File(imageName));
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public void showImage(BufferedImage img, String title) {
		JFrame imgframe = new JFrame();
		JLabel image = new JLabel(new ImageIcon(img));
		
		imgframe.add(image);
		imgframe.pack();
		
		imgframe.setTitle(title);
		
		imgframe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		imgframe.setResizable(false);
		imgframe.setVisible(true);
	}

	public BufferedImage getOriginal() {
		return img;
	}
	
	public int getThreshold() {
		return threshold;
	}
	
	public int[] getNeighbors(int x, int y, BufferedImage origimg) {
		int[] n = new int[9];
		
		n[0] = origimg.getRGB(x-1, y-1);
		n[1] = origimg.getRGB(x, y-1);
		n[2] = origimg.getRGB(x+1, y-1);
		n[3] = origimg.getRGB(x-1, y);
		n[4] = origimg.getRGB(x, y);
		n[5] = origimg.getRGB(x+1, y);
		n[6] = origimg.getRGB(x-1, y+1);
		n[7] = origimg.getRGB(x, y+1);
		n[8] = origimg.getRGB(x+1, y+1);
		
		return n;
	}
	
	public int[] getBrightnesses(int[] n) {
		int[] b = new int[9];
		
		for(int i = 0; i < b.length; i++) {
			int clr = n[i];
			
			int red   = (clr & 0x00ff0000) >> 16;
			int green = (clr & 0x0000ff00) >> 8;
			int blue  =  clr & 0x000000ff;
			
			b[i] = getBrightness(red, green, blue);
		}
		
		return b;
	}
	
	public int getMax(int[] n) {
		 int max = Integer.MIN_VALUE;
		 
		 for(int i = 0; i < n.length; i++) {
	      	  if(n[i] > max) {
	      		  max = n[i];
	      	  }
	     }
		 
		 return max;
	}
	
	public int getMin(int[] n) {
        int min = Integer.MAX_VALUE;
        
        for(int i = 0; i < n.length; i++) {
      	  if(n[i] < min) {
      		  min = n[i];
      	  }
        }
        
        return min;
	}
	
	public int getBrightness(int r, int g, int b) {
	   return (int) Math.sqrt(
	      r * r * .241 + 
	      g * g * .691 + 
	      b * b * .068);
	}
}

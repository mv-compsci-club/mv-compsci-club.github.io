import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;


public class NBCTest {
	private int TRAIN_NUM = 1250; // the number of spam and ham email text files we want to TRAIN the classifier with
	private int TEST_NUM = 250; // the number of spam or ham text files we want to TEST the classifier with
	
	public static void main(String args[]) throws Exception{
		NBCTest test = new NBCTest();
		
		boolean testWithSpam = true;
		if(args.length > 0)
			testWithSpam = Boolean.parseBoolean(args[0]);
		
		test.start(testWithSpam);
	}
	
	private void start(boolean testWithSpam) throws Exception {
		Classifier nbc = new Classifier(); // create the classifier object
		trainClassifier(nbc); // train the classifier
		testClassifier(nbc, testWithSpam); // test the classifier
	}

	private void trainClassifier(Classifier nbc) throws Exception {
		// list all the files in the spam and ham email training folders
		File[] spamFiles = new File("data/spamtrain").listFiles();
		File[] hamFiles = new File("data/hamtrain").listFiles();
		
		// read TRAIN_NUM files from each of the spam and ham directories and use them to train the classifier
		for(int i = 0; i < TRAIN_NUM; i++) {
			String spamText = readFile(spamFiles[i]);
			String hamText = readFile(hamFiles[i]);
			
			nbc.train(true, spamText); // train the NBC with the spam text
			nbc.train(false, hamText); // train the NBC with the ham text
		}
		
		System.out.println("Finished training classifier with " + TRAIN_NUM + " files.");
	}
	
	// tests the classifier after training it
	private void testClassifier(Classifier nbc, boolean testWithSpam) throws Exception {
		File[] testFiles = null;
		
		if(testWithSpam)
			testFiles = new File("data/spamtest").listFiles();
		else
			testFiles = new File("data/hamtest").listFiles();
		
		int numSpam = 0; // counts the number of spam emails detected
		
		for(int i = 0; i < TEST_NUM; i++) {
			String testText = readFile(testFiles[i]); // read text from the current test file
			System.out.print("Classifying " + testFiles[i].getName() + "...");
			
			boolean isSpam = nbc.classify(testText); // classify the text using the Classifier class
			
			if(isSpam) {
				System.out.println("SPAM!!");
				numSpam++; // if it is spam, increment numSpam
			} else {
				System.out.println("NOT SPAM");
			}
		}
		
		// print out the results
		double percentSpamDetected = (((double)numSpam) / TEST_NUM) * 100;
		System.out.println("\n============");
		System.out.printf("Classified %d out of %d files as spam --> %.1f%% %n", numSpam, TEST_NUM, percentSpamDetected);
	}
	
	// reads a given file and returns the text of the file as a single String
	private String readFile(File f) throws Exception {
		BufferedReader br = new BufferedReader(new FileReader(f));
	    try {
	        StringBuilder sb = new StringBuilder();
	        String line = br.readLine();
	
	        while (line != null) {
	            sb.append(line);
	            sb.append(' ');
	            line = br.readLine();
	        }
	        return sb.toString();
	    } finally {
	        br.close();
	    }
	}
}

public class GA {
    public static void main(String[] args) {
        int populationSize = 50; // the number of individuals in our population

    	// this is the candidate individual we want to reach 
    	String solution = "11110000000110000110001000000111110000000000001111";
    	System.out.println("\nTarget length=" + solution.length());
        System.out.println("Population size=" + populationSize);

    	System.out.println("Target: " + solution + "\n");
    	
        // Set the "ideal" solution
        FitnessCalc.setSolution(solution);

        // Create an initial population
        Population myPop = new Population(populationSize, true);
        
        System.out.printf("%s%9s %" + (solution.length()+5) + "s\n", "Gen#", "Genes", "Fitness");
        System.out.println("========================================================================================");
        
        // Evolve our population until we reach an optimum solution
        int generationCount = 0;
        while (myPop.getFittest().getFitness() < FitnessCalc.getMaxFitness()) { // while we haven't reached our desired fitness...
            generationCount++;
            System.out.printf("%2s      %11s   %3d (%.1f%%) %n", "" + generationCount, myPop.getFittest().toString(), 
            				myPop.getFittest().getFitness(), ((double)myPop.getFittest().getFitness()/solution.length()*100)); // print out current info 
            
            myPop = Algorithm.evolvePopulation(myPop);
        }

        System.out.println("\nGenes:  " + myPop.getFittest());
        System.out.println("Solution found after " + (generationCount+1) + " generations.");
    }
}
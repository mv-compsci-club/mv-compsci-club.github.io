import java.util.HashMap;
import java.util.Map;

// stores the frequency of each word as they occur in the emails
// categorized as either spam or ham.
public class Store {
	private Map<String, Integer> spamFreqs;
	private Map<String, Integer> hamFreqs;
	
	private int categoryCount;
	
	public Store() {
		spamFreqs = new HashMap<String, Integer>();
		hamFreqs = new HashMap<String, Integer>();
		
		categoryCount = 2;
	}
	
	public void incrementFrequency(boolean isSpam, String word) {
		if(isSpam) {
			if(spamFreqs.containsKey(word))
				spamFreqs.put(word, spamFreqs.get(word)+1);
			else
				spamFreqs.put(word, 1);
		} else {
			if(hamFreqs.containsKey(word))
				hamFreqs.put(word, hamFreqs.get(word)+1);
			else
				hamFreqs.put(word, 1);
		}
	}
	
	public int getTotalWordsCount(boolean spamStore) {
		Map<String, Integer> map = spamStore ? spamFreqs : hamFreqs;
		int num = 0;
		for(String word : map.keySet()) {
			num += map.get(word);
		}
		
		return num;
	}

	public int getFrequency(boolean isSpam, String word) {
		Integer freq = 0;
		if(isSpam)
			freq =  spamFreqs.get(word);
		else
			freq = hamFreqs.get(word);
		
		if(freq != null)
			return freq.intValue();
		else
			return 0;
	}
	
	public int getCategoryCount() {
		return categoryCount;
	}
}

import java.awt.Color;
import java.awt.image.BufferedImage;

public class EdgeDetectionTest {
	EdgeDetectionHelper detector;
	
	public static void main(String args[]) {
		EdgeDetectionTest test = new EdgeDetectionTest ();
		int threshold = 0;
		if(args.length == 2)
			threshold = Integer.parseInt(args[1]);
		else
			threshold = 25;
		
		test.startTest(args[0], threshold);
	}
	
	public void startTest(String imageName, int threshold) {
		detector = new EdgeDetectionHelper(threshold, imageName);
		
		BufferedImage oldImage = detector.getOriginal();
		BufferedImage newImage = new BufferedImage(oldImage.getWidth(), oldImage.getHeight(), oldImage.getType());
		
		doEdgeDetection(oldImage, newImage);
		
		detector.showImage(oldImage, "Original");
		detector.showImage(newImage, "Edge-detection");
	}

	private void doEdgeDetection(BufferedImage oldimg, BufferedImage newimg) {
		for (int x = 1; x < oldimg.getWidth()-1; x++) {
		    for (int y = 1; y < oldimg.getHeight()-1; y++) {
		    	int[] neighbors = detector.getNeighbors(x, y, oldimg);
		    	int[] bright = detector.getBrightnesses(neighbors);
		    	
		    	int max = detector.getMax(bright);
		    	int min = detector.getMin(bright);
		    	
		    	int delta = max - min;
		    	
		    	if(delta > detector.getThreshold())
		    		newimg.setRGB(x, y, Color.black.getRGB());
		    	else
		    		newimg.setRGB(x, y, Color.white.getRGB());
		    }
		}
	}
}

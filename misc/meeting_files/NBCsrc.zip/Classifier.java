import java.util.ArrayList;
import java.util.List;


public class Classifier {
	private TokenizerProps props; // this file is used to check if a word is valid or not
	private Store store; // this file stores a mapping from each unique word to the # of times it has occured
	
	public Classifier() {
		props = new TokenizerProps();
		props.intialize();
		store = new Store();
	}
	
	// trains the classifier with the passed text, categorized as spam or ham w/ the isSpam paramter
	public void train(boolean isSpam, String text) {
		String[] words = cleanTokens(text.trim().split(" ")); // clean the text and returns the contained words
		
		for(String currWord : words) {
			store.incrementFrequency(isSpam, currWord); // increment the frequency of each word that occurs
		}
	}
	
	// removes undesired words from an array of words
	private String[] cleanTokens(String[] toks) {
		List<String> cleaned = new ArrayList<String>();
		for(int i = 0; i < toks.length; i++) {
			String curr = toks[i].trim();
			if(props.isValidWord(curr)) {
				cleaned.add(curr);
			}
		}
		
		return cleaned.toArray(new String[cleaned.size()]);
	}
	
	// classifies a given text as spam, or not spam, and returns the value through a boolean
	public boolean classify(String text) {
		String[] words = cleanTokens(text.trim().split(" "));
		double spamProb = 0d, hamProb = 0d;
		double categoryProb = Math.log(1.0d / store.getCategoryCount());
		
		int numSpam = store.getTotalWordsCount(true); // number of total stored spam words stored
		int numHam = store.getTotalWordsCount(false); // number of total stored ham words stored
		
		for(int i = 0; i < words.length; i++) {
			String word = words[i];
			
			double spamWordProb = (double)store.getFrequency(true, word) / numSpam;
			double hamWordProb = (double)store.getFrequency(false, word) / numHam;
			
			if(spamWordProb == 0d || hamWordProb == 0d) 
				continue;
			
			spamProb = spamProb + Math.log(spamWordProb);
			hamProb = hamProb + Math.log(hamWordProb);
		}
		
		spamProb = spamProb + categoryProb;
		hamProb = hamProb + categoryProb;
		
		// if the probability of the text being spam is greater than it being ham, return true
		// else, return false
		if(spamProb > hamProb)
			return true;
		else
			return false;
	}
}